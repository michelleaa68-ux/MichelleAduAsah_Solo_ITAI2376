# Design System & Style Guide

## Brand Identity

### Voice & Tone
- **Luxurious but Approachable**: Premium service with friendly, helpful communication
- **Creative & Inspiring**: Spark imagination and possibilities
- **Professional & Trustworthy**: Reliable and detailed expertise
- **Warm & Inviting**: Especially welcoming to brides and celebration planners

### Core Values
- Transformation through design
- Attention to detail
- Client-first service
- Creative excellence
- Seamless execution

## Color System

### Primary Colors
```
Rose/Pink (Primary): #DB2777 (340° 82% 52%)
- Used for: CTAs, highlights, brand accent
- Usage: Buttons, links, important highlights
- Shade variant: #9D174D (darker) for hover states
```

```
Gold (Secondary): #FFB300 (45° 96% 56%)
- Used for: Luxury accents, secondary CTAs
- Usage: Accent elements, secondary buttons
- Shade variant: #D97706 (darker) for hover states
```

### Neutral Colors
```
Cream (Background): #FFFCF0 (60° 40% 96%)
- Used for: Primary background, soft areas
- Accessibility: Readable with foreground text

Foreground (Text): #453420 (20° 20% 15%)
- Used for: Body text, primary text color
- High contrast with backgrounds

White: #FFFFFF (0° 0% 100%)
- Used for: Cards, popups, high-contrast areas
```

### Extended Palette
```
Rose 50-900:   Gradients and variations
Gold 50-900:   Luxury accents and transitions
Cream 50-900:  Background variations
```

## Typography

### Font Families
```css
Display Font: Playfair Display
- Weight: 700, 800
- Usage: H1, H2, H3, headings
- Characteristics: Elegant, sophisticated

Body Font: Inter
- Weight: 300, 400, 500, 600, 700, 800
- Usage: Body text, labels, buttons, UI
- Characteristics: Clean, modern, highly readable
```

### Type Scale
```
H1: 48px (desktop) / 32px (mobile)
    font-display text-5xl md:text-6xl

H2: 40px (desktop) / 24px (mobile)
    font-display text-3xl md:text-5xl

H3: 28px (desktop) / 20px (mobile)
    font-display text-xl md:text-2xl

Body: 16px
    text-base

Small: 14px
    text-sm

Tiny: 12px
    text-xs
```

### Font Weights
- **Headings**: 700-800 (bold, attention-grabbing)
- **UI Labels**: 600 (prominent but not dominant)
- **Body**: 400 (readable, comfortable)
- **Light**: 300 (secondary info, subtle)

## Component Styles

### Buttons

#### Primary Button
```tsx
className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-rose-700 transition-colors duration-200 shadow-lg hover:shadow-xl"
```
- Rose pink background
- White text
- Rounded corners
- Shadow on hover
- Use for: Main CTAs, important actions

#### Secondary Button
```tsx
className="px-6 py-3 bg-secondary text-secondary-foreground rounded-lg font-semibold hover:bg-gold-600 transition-colors duration-200"
```
- Gold background
- Dark text
- Use for: Luxury accents, secondary actions

#### Outline Button
```tsx
className="px-6 py-3 border-2 border-primary text-primary rounded-lg font-semibold hover:bg-rose-50 transition-colors duration-200"
```
- Transparent background
- Pink border
- Pink text
- Use for: Tertiary actions, links

### Cards
```tsx
className="card-luxury"
// Expands to:
className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-8 border border-cream-200"
```
- White background
- Cream border
- Large padding
- Subtle shadows
- Hover elevation

### Text Gradient
```tsx
className="text-gradient"
// Rose → Dusty Rose → Gold gradient
```

## Spacing System

```
0.5rem (8px)
1rem (16px)
1.5rem (24px)
2rem (32px)
3rem (48px)
4rem (64px)
5rem (80px)
6rem (96px)
```

## Border Radius
```
Small:   0.25rem (4px)
Medium:  0.5rem (8px)
Large:   0.75rem (12px)
XLarge:  1rem (16px)
2XLarge: 1.25rem (20px)
```

## Shadows

### Subtle
```css
box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
```

### Standard (card-luxury)
```css
box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
```

### Emphasis (hover)
```css
box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
```

## Animations

### Fade In
```css
animation: fade-in 0.6s ease-out;
```
- Used for: Page loads, content reveals
- Duration: 600ms
- Easing: ease-out

### Slide Up
```css
animation: slide-up 0.6s ease-out;
```
- Used for: Modal opens, element entrance
- Starting: 20px down, 0% opacity
- Ending: 0px, 100% opacity

### Bounce
```css
animation: bounce;
```
- Used for: Loading indicators, attention
- Infinite loop with delays

## Interactive States

### Hover
- Slight shadow elevation
- Color darkening (primary: -10% lightness)
- Cursor pointer
- Smooth transition (200ms)

### Focus
- Ring outline: 2px
- Ring color: Primary with 20% opacity
- Ring offset: 2px
- Used for: Accessibility

### Active/Pressed
- Enhanced shadow
- Color shift
- Slight scale reduction

### Disabled
- Opacity: 50%
- Cursor: not-allowed
- No hover effects
- Color: Muted foreground

## Responsive Design

### Breakpoints
```
Mobile:      < 640px
Tablet:      ≥ 640px  (sm:)
Desktop:     ≥ 768px  (md:)
Large:       ≥ 1024px (lg:)
XLarge:      ≥ 1280px (xl:)
2XLarge:     ≥ 1536px (2xl:)
```

### Mobile-First Approach
- Design for mobile first
- Enhance for larger screens
- Use `sm:`, `md:`, `lg:` prefixes
- Test on actual devices

### Layout Patterns
```
Mobile: Single column, stacked
Tablet: 2 columns
Desktop: 3+ columns, side panels
```

## Accessibility

### Color Contrast
- WCAG AA: 4.5:1 (normal text)
- WCAG AAA: 7:1 (enhanced)
- Test all color combinations

### Focus States
- Clear focus indicators
- Keyboard navigation support
- Tab order logical and visible

### Alternative Text
- Meaningful alt text for images
- Skip navigation links
- Descriptive labels

### Motion
- Respect `prefers-reduced-motion`
- Keep animations under 1 second
- Avoid auto-playing animations

## Best Practices

### Layout
1. Use max-width containers (max-w-6xl typically)
2. Maintain adequate padding (px-4 on mobile)
3. Consistent vertical rhythm
4. White space is valuable

### Typography
1. Limit line length (40-65 characters ideal)
2. Proper heading hierarchy
3. Adequate line height (1.5-1.75)
4. Sufficient color contrast

### Components
1. Consistent sizing
2. Clear affordances (buttons look clickable)
3. Provide feedback (hover, active states)
4. Avoid cognitive overload

### Forms
1. Clear labels
2. Helpful placeholder text
3. Error messages that guide
4. Success confirmations

## Dark Mode Support

The theme structure supports dark mode with CSS variables in the `:root.dark` selector. To implement:

1. Add dark mode styles to `global.css`
2. Update Tailwind config: `darkMode: ["class"]`
3. Add toggle functionality
4. Test contrast in dark mode

## Code Examples

### Creating a New Card
```tsx
<div className="card-luxury">
  <h3 className="font-display text-2xl text-foreground mb-4">
    Title
  </h3>
  <p className="text-foreground/70">Content</p>
</div>
```

### Creating a CTA Section
```tsx
<section className="py-20 md:py-32 px-4 bg-gradient-to-r from-primary/10 to-secondary/10">
  <div className="max-w-2xl mx-auto text-center space-y-8">
    <h2 className="font-display text-4xl md:text-5xl text-foreground">
      Heading
    </h2>
    <p className="text-lg text-foreground/70">Subheading</p>
    <a href="/" className="inline-flex items-center gap-2 btn-primary">
      CTA Text <ArrowRight className="w-5 h-5" />
    </a>
  </div>
</section>
```

### Responsive Grid
```tsx
<div className="grid md:grid-cols-3 gap-8">
  {items.map(item => (
    <div key={item.id} className="card-luxury">
      {/* content */}
    </div>
  ))}
</div>
```

## Testing Checklist

- [ ] All colors pass WCAG contrast requirements
- [ ] Animations work smoothly on lower-end devices
- [ ] Mobile layout is readable and usable
- [ ] Responsive images load correctly
- [ ] Forms are accessible via keyboard
- [ ] Focus states are visible
- [ ] No layout shifts during interactions
- [ ] Load times are optimal
- [ ] Dark mode renders correctly (if implemented)
- [ ] Touch targets are 44px minimum

---

**Last Updated**: 2026
**Version**: 1.0
