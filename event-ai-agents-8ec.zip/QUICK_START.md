# Quick Start Guide - Transforming Spaces AI Agents

## Getting Started

### 1. **Start the Development Server**
```bash
pnpm dev
```
The app will start on `http://localhost:8080`

### 2. **Explore the Homepage**
Visit `/` to see:
- Beautiful hero section introducing the brand
- Cards showcasing all 3 agents
- Feature highlights
- Calls-to-action

## Using the Three Agents

### 🎤 MIRA - Client Assistant
**URL**: `/mira`

**What to Try**:
- Ask about pricing ("What are your pricing options?")
- Ask about availability ("What areas do you service?")
- Ask about bookings ("How do I book an appointment?")
- Ask about refunds ("What's your cancellation policy?")
- Ask about specific items (chandeliers, flowers, tables)

**How It Works**:
- MIRA intelligently detects keywords in your questions
- Returns relevant, helpful responses
- Click quick suggestion buttons or type your own questions

**Example Questions**:
- "How much do you charge?"
- "Do you deliver?"
- "What about flowers?"
- "Can I change my booking?"

---

### 🎨 MIZEL - Creative Director
**URL**: `/mizel`

**What to Try**:
1. Describe your event vision in the text box
2. Click "Generate Mood Board"
3. View your custom color palette and mood board

**Example Visions**:
- "Romantic garden wedding with white flowers and gold accents"
- "Blush pink celebration with champagne details"
- "Royal blue ballroom with dramatic lighting"
- "Modern minimalist with clean lines"

**What You Get**:
- 3-color custom palette with hex codes
- Detailed mood board recommendations
- Floral suggestions
- Lighting guidance
- Design narrative
- Next steps to bring your vision to life

---

### 📦 MILO - Inventory System
**URL**: `/milo`

**Security**:
- Password Protected (Workers Only)
- Passcode: `milo2376`

**What to Try**:
1. Enter the worker passcode
2. View complete inventory organized by category
3. Check stock levels
4. See low-stock alerts (items with ≤10 units)

**Inventory Categories**:
- Furniture (Chairs, Tables)
- Tableware (Chargers, Silverware)
- Linens (Tablecloths, Napkins)
- Lighting (Candelabras, Uplighting)
- Decor (Floral Arches, Wall Panels)

**Low Stock Items**:
- 🚨 Floral Arches: 3 units
- 🚨 Flower Wall Panels: 8 units

---

## Navigation

### Top Navigation Bar
- **Logo/Home**: Click to go to homepage
- **Home**: `/`
- **MIRA**: `/mira` (Chat)
- **MIZEL**: `/mizel` (Design)
- **MILO**: `/milo` (Inventory)

### Footer
- Quick links to all pages
- Contact information
- Company description

---

## Customization Guide

### Editing MIRA's Responses
**File**: `client/pages/MiraPage.tsx`

Find the `MIRA_RESPONSES` object:
```tsx
const MIRA_RESPONSES: Record<string, string> = {
  price: `Your response text here...`,
  // ... more responses
};
```

To add a new question type:
1. Add a new entry to `MIRA_RESPONSES`
2. Update the `getSuggestions()` function with new keywords

---

### Changing Colors
**Files**: 
- `client/global.css` (CSS variables)
- `tailwind.config.ts` (Tailwind config)

**Update Theme**:
```css
/* In global.css :root section */
--primary: 340 82% 52%;      /* Change rose pink */
--secondary: 45 96% 56%;      /* Change gold */
--background: 60 40% 96%;     /* Change cream */
```

---

### Adding MIZEL Palettes
**File**: `client/pages/MizelPage.tsx`

Add to `DESIGN_PALETTES`:
```tsx
yourPalette: {
  name: "Your Palette Name",
  colors: [
    { name: "Color 1", hex: "#HEXCODE", description: "..." },
    { name: "Color 2", hex: "#HEXCODE", description: "..." },
    { name: "Color 3", hex: "#HEXCODE", description: "..." },
  ],
  moodBoard: `Your mood board text here...`,
  vibe: "Your vibe description",
},
```

Update keyword detection in `generateMoodBoard()`:
```tsx
if (lower.includes("your_keyword")) {
  palette = DESIGN_PALETTES.yourPalette;
}
```

---

### Updating MILO Inventory
**File**: `client/pages/MiloPage.tsx`

Edit the `INVENTORY` array:
```tsx
const INVENTORY: InventoryItem[] = [
  { name: "Item Name", quantity: 50, category: "Category", sku: "SKU-001" },
  // Add more items
];
```

Change worker passcode:
```tsx
const WORKER_PASSCODE = "your_new_passcode";
```

---

## Styling

### Font Sizes (Tailwind Classes)
- `text-xs`: 12px (tiny)
- `text-sm`: 14px (small)
- `text-base`: 16px (normal)
- `text-lg`: 18px (large)
- `text-xl`: 20px (extra large)
- `text-2xl`: 24px (2x)
- `text-4xl`: 36px (heading)
- `text-6xl`: 60px (hero heading)

### Common Component Classes
- `.card-luxury`: White card with shadows
- `.btn-primary`: Rose button
- `.btn-secondary`: Gold button
- `.btn-outline`: Outline button
- `.text-gradient`: Gradient text effect
- `.font-display`: Playfair Display font

### Responsive Prefixes
- `sm:`: Small screens (≥640px)
- `md:`: Medium screens (≥768px)
- `lg:`: Large screens (≥1024px)

---

## Content Examples

### Adding a Feature
```tsx
<div className="card-luxury">
  <Sparkles className="w-8 h-8 text-primary mb-4" />
  <h3 className="font-display text-2xl text-foreground mb-3">
    Feature Name
  </h3>
  <p className="text-foreground/70 mb-6">
    Feature description goes here.
  </p>
  <Link to="/page" className="text-primary font-semibold hover:gap-3">
    Learn More →
  </Link>
</div>
```

### Adding a CTA
```tsx
<div className="text-center space-y-4">
  <h2 className="font-display text-4xl text-foreground">
    Call to Action
  </h2>
  <p className="text-foreground/60">Subtitle or description</p>
  <Link to="/page" className="inline-flex items-center gap-2 btn-primary">
    Action Text <ArrowRight className="w-5 h-5" />
  </Link>
</div>
```

---

## Testing Locally

### Test All Pages
- [ ] Homepage (`/`)
- [ ] MIRA Chat (`/mira`) - Try different questions
- [ ] MIZEL Design (`/mizel`) - Try different visions
- [ ] MILO Inventory (`/milo`) - Use passcode `milo2376`
- [ ] Not Found (`/invalid-page`)

### Test Responsiveness
- Open DevTools (F12)
- Toggle device toolbar
- Test on mobile, tablet, desktop sizes
- Check all navigation links work

### Test Interactions
- Hover states on buttons
- Click all links
- Type in input fields
- Check animations play smoothly

---

## Troubleshooting

### Page Not Loading
1. Check console for errors (F12)
2. Verify import paths are correct
3. Ensure component files exist
4. Check for typos in file names

### Styling Issues
1. Clear browser cache (Ctrl+Shift+Delete)
2. Restart dev server (`pnpm dev`)
3. Check Tailwind classes are valid
4. Verify CSS variables in `global.css`

### MILO Not Working
1. Check passcode is `milo2376`
2. Verify `WORKER_PASSCODE` matches
3. Check browser console for errors
4. Ensure inventory array is populated

---

## Next Steps

1. **Customize Colors**: Update theme colors in `global.css`
2. **Add Your Content**: Update contact info, company name, etc.
3. **Expand MIRA**: Add more Q&A responses
4. **Create More Palettes**: Add design options to MIZEL
5. **Connect a Database**: Store inventory and responses
6. **Add Real AI**: Connect to Claude or another LLM API
7. **Deploy**: Use Netlify or Vercel MCP integration

---

## Help & Support

**Documentation Files**:
- `PROJECT_OVERVIEW.md` - Complete project documentation
- `DESIGN_GUIDE.md` - Design system and components
- `QUICK_START.md` - This file

**Code Structure**:
- Pages handle routing
- Layout provides shared structure
- Components are reusable
- Styles use Tailwind classes

---

**Happy Building! 🚀**

For questions about the design or functionality, refer to the documentation files or explore the source code directly.
