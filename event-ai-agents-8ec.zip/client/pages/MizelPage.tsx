import { useState } from "react";
import { Palette, Sparkles, RefreshCw } from "lucide-react";

interface Palette {
  name: string;
  colors: { name: string; hex: string; description: string }[];
  moodBoard: string;
  vibe: string;
}

const DESIGN_PALETTES: Record<string, Palette> = {
  garden: {
    name: "Garden Romance",
    colors: [
      { name: "Ivory White", hex: "#FFFEF9", description: "Pure elegance" },
      { name: "Sage Green", hex: "#9CAF88", description: "Natural grace" },
      { name: "Soft Gold", hex: "#D4AF87", description: "Warm luxury" },
    ],
    moodBoard: `✨ Garden Romance Mood Board

🌹 Linens & Base:
Ivory white linen tablecloths with sage green napkin folds

🪴 Tabletop Details:
Soft gold charger plates, sage green details with trailing greenery

🌸 Florals:
Low, lush garden arrangements with:
- White ranunculus
- Eucalyptus & trailing ivy
- Greenery at varying heights

💡 Lighting:
Slim gold pillar candles at varying heights
Warm, ambient glow

✨ Overall Feel:
Organic, romantic, and incredibly cohesive—a sanctuary of natural beauty`,
    vibe: "Organic, romantic, garden-inspired luxury",
  },
  blush: {
    name: "Blush Elegance",
    colors: [
      { name: "Blush Pink", hex: "#F8C9D4", description: "Soft romance" },
      { name: "Champagne Gold", hex: "#F5D0A9", description: "Warm glamour" },
      { name: "Dusty Rose", hex: "#D4A5A5", description: "Refined elegance" },
    ],
    moodBoard: `💕 Blush Elegance Mood Board

🎀 Linens & Base:
Blush pink linen tablecloths with champagne undertones

🥇 Tabletop Details:
Champagne gold charger plates with soft pink accents

🌷 Florals:
Low, romantic arrangements featuring:
- Blush & garden roses
- White peonies
- Baby's breath in abundance
- Champagne ribbon napkin ties

💡 Lighting:
Warm candlelight from gold candelabras
Soft, romantic ambiance throughout

✨ Overall Feel:
Romantic, luxurious, feminine—pure wedding magic`,
    vibe: "Romantic, feminine, champagne luxury",
  },
  royal: {
    name: "Royal Grandeur",
    colors: [
      { name: "Royal Blue", hex: "#4169E1", description: "Bold elegance" },
      { name: "Gold", hex: "#FFD700", description: "Regal accent" },
      { name: "Crisp White", hex: "#FFFFFF", description: "Pure contrast" },
    ],
    moodBoard: `👑 Royal Grandeur Mood Board

💎 Linens & Base:
Deep royal blue velvet linen tablecloths

🥇 Tabletop Details:
Bright gold charger plates with white place settings
White flowers pop against the rich backdrop

🌸 Florals:
Tall centerpiece arrangements (ballroom impact):
- White hydrangeas
- White & ivory orchids
- Gold ribbon accents throughout
- Lush greenery for drama

💡 Lighting:
Gold candelabras on alternating tables
Dramatic uplighting in gold tones

✨ Overall Feel:
Grand, regal, ballroom-worthy—pure sophistication`,
    vibe: "Grand, regal, ballroom elegance",
  },
  burgundy: {
    name: "Burgundy Luxury",
    colors: [
      { name: "Deep Burgundy", hex: "#800020", description: "Rich drama" },
      { name: "Forest Green", hex: "#228B22", description: "Natural depth" },
      { name: "Warm Gold", hex: "#B8860B", description: "Luxury shine" },
    ],
    moodBoard: `🍷 Burgundy Luxury Mood Board

🍂 Linens & Base:
Rich burgundy velvet linen tablecloths

🥇 Tabletop Details:
Warm gold charger plates with burgundy details
Dark velvet napkins in burgundy or forest green

🌹 Florals:
Lush, dramatic tall arrangements featuring:
- Deep red roses
- Burgundy dahlias
- Lush greenery & texture
- Arranged in tall gold vases

💡 Lighting:
Gold candelabras with deep amber candlelight
Warm, intimate ambiance

✨ Overall Feel:
Bold, luxurious, dramatically romantic—unforgettable impact`,
    vibe: "Bold, luxurious, dramatic romance",
  },
  minimalist: {
    name: "Modern Minimalist",
    colors: [
      { name: "Crisp White", hex: "#FFFFFF", description: "Clean canvas" },
      { name: "Slate Grey", hex: "#708090", description: "Modern tone" },
      { name: "Brushed Silver", hex: "#C0C0C0", description: "Refined accent" },
    ],
    moodBoard: `✨ Modern Minimalist Mood Board

🤍 Linens & Base:
Crisp white linen tablecloths
Slate grey or brushed silver accents

🥄 Tabletop Details:
Brushed silver charger plates
Minimal, structured place settings

🌼 Florals:
Minimal, low centerpieces (less is more):
- White calla lilies
- Structured greenery
- Simple, purposeful arrangements
- White taper candles in silver holders

💡 Lighting:
Clean, white candlelight
Modern, architectural arrangements

✨ Overall Feel:
Refined, sophisticated, intentional—where every element matters`,
    vibe: "Modern, refined, minimalist elegance",
  },
  default: {
    name: "Timeless Warmth",
    colors: [
      { name: "Ivory", hex: "#FFFFF0", description: "Warm white" },
      { name: "Soft Gold", hex: "#F5DEB3", description: "Golden warmth" },
      { name: "Warm Blush", hex: "#FFB6C1", description: "Soft romance" },
    ],
    moodBoard: `💫 Timeless Warmth Mood Board

🤎 Linens & Base:
Ivory linens with soft gold and blush accents

🥇 Tabletop Details:
Gold charger plates with warm tones

🌸 Florals:
Mixed floral centerpieces in warm tones:
- Peach roses
- Champagne-hued flowers
- Warm greenery
- Natural, flowing arrangements

💡 Lighting:
Warm candlelight throughout
Intimate, inviting ambiance

✨ Overall Feel:
Warm, inviting, timeless—perfectly elegant`,
    vibe: "Warm, inviting, classically beautiful",
  },
};

export default function MizelPage() {
  const [visionInput, setVisionInput] = useState("");
  const [selectedPalette, setSelectedPalette] = useState<Palette | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateMoodBoard = async () => {
    if (!visionInput.trim()) return;

    setIsGenerating(true);
    await new Promise((resolve) => setTimeout(resolve, 1200));

    const lower = visionInput.toLowerCase();

    let palette: Palette;
    if (
      (lower.includes("white") || lower.includes("garden") || lower.includes("flower")) &&
      !lower.includes("pink") &&
      !lower.includes("blue") &&
      !lower.includes("red")
    ) {
      palette = DESIGN_PALETTES.garden;
    } else if (
      lower.includes("blush") ||
      lower.includes("pink") ||
      lower.includes("romantic") ||
      lower.includes("rose")
    ) {
      palette = DESIGN_PALETTES.blush;
    } else if (
      lower.includes("royal") ||
      lower.includes("blue") ||
      lower.includes("grand") ||
      lower.includes("regal")
    ) {
      palette = DESIGN_PALETTES.royal;
    } else if (
      lower.includes("red") ||
      lower.includes("burgundy") ||
      lower.includes("bold") ||
      lower.includes("luxury")
    ) {
      palette = DESIGN_PALETTES.burgundy;
    } else if (
      lower.includes("minimalist") ||
      lower.includes("simple") ||
      lower.includes("clean") ||
      lower.includes("modern")
    ) {
      palette = DESIGN_PALETTES.minimalist;
    } else {
      palette = DESIGN_PALETTES.default;
    }

    setSelectedPalette(palette);
    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream-50 via-background to-cream-50 py-8 md:py-12">
      <div className="max-w-5xl mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-secondary/10 border border-secondary/20 rounded-full px-4 py-2">
            <Palette className="w-5 h-5 text-secondary" />
            <span className="font-semibold text-secondary">MIZEL Creative Director</span>
          </div>

          <h1 className="font-display text-4xl md:text-5xl text-foreground">
            Your Design Vision Awaits
          </h1>
          <p className="text-lg text-foreground/60">
            Describe your dream event and let MIZEL create a custom mood board and color palette
          </p>
        </div>

        {/* Input Section */}
        <div className="bg-white rounded-2xl border border-cream-200 shadow-lg p-8 mb-8">
          <label className="block mb-4">
            <span className="text-sm font-semibold text-foreground uppercase tracking-wide mb-3 block">
              🎨 Describe Your Vision
            </span>
            <textarea
              value={visionInput}
              onChange={(e) => setVisionInput(e.target.value)}
              placeholder="Tell me about your event... What's the mood? Colors you're drawn to? Style? Examples: 'Romantic garden wedding with blush tones', 'Modern minimalist with clean lines', 'Grand ballroom with royal blue and gold'..."
              className="w-full px-4 py-4 border border-cream-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/20 focus:border-secondary bg-cream-50 resize-none h-24 placeholder-foreground/40"
            />
          </label>

          <button
            onClick={generateMoodBoard}
            disabled={!visionInput.trim() || isGenerating}
            className="w-full bg-gradient-to-r from-secondary to-gold-500 hover:from-gold-600 hover:to-gold-700 disabled:from-foreground/20 disabled:to-foreground/20 text-foreground disabled:text-foreground/40 font-bold py-4 rounded-xl transition-all duration-200 flex items-center justify-center gap-2 text-lg"
          >
            {isGenerating ? (
              <>
                <div className="w-5 h-5 border-2 border-foreground border-t-transparent rounded-full animate-spin"></div>
                <span>Creating Your Mood Board...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-6 h-6" />
                <span>Generate Mood Board</span>
              </>
            )}
          </button>
        </div>

        {/* Palette Display */}
        {selectedPalette && (
          <div className="space-y-8 animate-slide-up">
            {/* Palette Header */}
            <div className="text-center space-y-3">
              <h2 className="font-display text-4xl text-gradient">
                {selectedPalette.name}
              </h2>
              <p className="text-lg text-foreground/70 italic">
                {selectedPalette.vibe}
              </p>
            </div>

            {/* Color Swatches */}
            <div className="bg-white rounded-2xl border border-cream-200 shadow-lg overflow-hidden">
              <div className="grid grid-cols-3 gap-0">
                {selectedPalette.colors.map((color, i) => (
                  <div key={i} className="flex flex-col">
                    <div
                      style={{ backgroundColor: color.hex }}
                      className="h-32 md:h-40 transition-transform hover:scale-105"
                    ></div>
                    <div className="p-4 bg-white flex-1 flex flex-col justify-between">
                      <div>
                        <p className="font-semibold text-foreground">{color.name}</p>
                        <p className="text-sm text-foreground/60">{color.description}</p>
                      </div>
                      <p className="text-xs text-foreground/40 font-mono">{color.hex}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Mood Board Text */}
            <div className="bg-white rounded-2xl border border-cream-200 shadow-lg p-8 md:p-12">
              <div className="flex items-center gap-3 mb-6">
                <Palette className="w-6 h-6 text-secondary" />
                <h3 className="font-display text-2xl text-foreground">
                  Complete Mood Board
                </h3>
              </div>

              <div className="whitespace-pre-wrap text-foreground/80 leading-relaxed font-medium space-y-4">
                {selectedPalette.moodBoard}
              </div>
            </div>

            {/* Design Details */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card-luxury">
                <h4 className="font-display text-xl text-secondary mb-4">
                  ✨ Design Elements
                </h4>
                <ul className="space-y-3 text-foreground/70">
                  <li className="flex items-start gap-3">
                    <span className="text-secondary font-bold flex-shrink-0">•</span>
                    <span>Color psychology perfectly matched to your vision</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-secondary font-bold flex-shrink-0">•</span>
                    <span>Floral selections that complement each hue</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-secondary font-bold flex-shrink-0">•</span>
                    <span>Lighting design for maximum impact</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-secondary font-bold flex-shrink-0">•</span>
                    <span>Tableware and linens coordinated perfectly</span>
                  </li>
                </ul>
              </div>

              <div className="card-luxury">
                <h4 className="font-display text-xl text-secondary mb-4">
                  💫 Next Steps
                </h4>
                <div className="space-y-4 text-foreground/70">
                  <p>
                    Love this design? Schedule a consultation with our team to:
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <span className="text-secondary font-bold">1.</span>
                      <span>Review fabric swatches and samples</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-secondary font-bold">2.</span>
                      <span>Finalize floral selections</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-secondary font-bold">3.</span>
                      <span>Customize based on your venue and budget</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-secondary font-bold">4.</span>
                      <span>Receive your complete design package</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* CTA */}
            <div className="bg-gradient-to-r from-secondary/10 to-primary/10 border border-secondary/20 rounded-2xl p-8 text-center space-y-4">
              <h3 className="font-display text-2xl text-foreground">
                Ready to Bring This Vision to Life?
              </h3>
              <p className="text-foreground/70 mb-4">
                Contact MIRA to schedule your design consultation
              </p>
              <button
                onClick={() => setVisionInput("")}
                className="inline-flex items-center gap-2 btn-primary mx-auto"
              >
                <RefreshCw className="w-4 h-4" />
                Create Another Design
              </button>
            </div>
          </div>
        )}

        {/* Example Visions */}
        {!selectedPalette && (
          <div className="mt-12">
            <h3 className="font-display text-2xl text-foreground text-center mb-8">
              Or Try One of These Visions
            </h3>

            <div className="grid md:grid-cols-2 gap-6">
              {[
                "Romantic garden wedding with white flowers, sage green, and soft gold—pure elegance",
                "Blush pink celebration with champagne gold accents and garden roses",
                "Royal blue ballroom wedding with white florals and dramatic gold lighting",
                "Modern minimalist event with clean lines, white, and brushed silver details",
              ].map((vision, i) => (
                <button
                  key={i}
                  onClick={() => setVisionInput(vision)}
                  className="card-luxury text-left hover:shadow-2xl transition-all duration-300"
                >
                  <p className="text-foreground/80 leading-relaxed mb-4">
                    {vision}
                  </p>
                  <span className="inline-flex items-center gap-2 text-secondary font-semibold">
                    Try This <Sparkles className="w-4 h-4" />
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
