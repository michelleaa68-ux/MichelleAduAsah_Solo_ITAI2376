import { useState } from "react";
import { Package, Lock, AlertTriangle, CheckCircle2, Eye, EyeOff } from "lucide-react";

const WORKER_PASSCODE = "milo2376";

interface InventoryItem {
  name: string;
  quantity: number;
  category: string;
  sku: string;
}

const INVENTORY: InventoryItem[] = [
  { name: "Chairs", quantity: 150, category: "Furniture", sku: "CH-001" },
  { name: "Tables", quantity: 20, category: "Furniture", sku: "TB-001" },
  { name: "Charger Plates", quantity: 200, category: "Tableware", sku: "CP-001" },
  {
    name: "Linen Tablecloths",
    quantity: 40,
    category: "Linens",
    sku: "LT-001",
  },
  { name: "Linen Napkins", quantity: 300, category: "Linens", sku: "LN-001" },
  {
    name: "Silverware Sets",
    quantity: 250,
    category: "Tableware",
    sku: "SW-001",
  },
  { name: "Floral Arches", quantity: 3, category: "Decor", sku: "FA-001" },
  { name: "Candelabras", quantity: 12, category: "Lighting", sku: "CL-001" },
  {
    name: "Uplighting Units",
    quantity: 24,
    category: "Lighting",
    sku: "UL-001",
  },
  { name: "Flower Wall Panels", quantity: 8, category: "Decor", sku: "FWP-001" },
];

export default function MiloPage() {
  const [passcode, setPasscode] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showPasscode, setShowPasscode] = useState(false);
  const [authError, setAuthError] = useState("");

  const handleAuthenticate = () => {
    if (passcode === WORKER_PASSCODE) {
      setIsAuthenticated(true);
      setAuthError("");
    } else {
      setAuthError("❌ Incorrect passcode. Access denied.");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setPasscode("");
    setAuthError("");
  };

  const getLowStockItems = () =>
    INVENTORY.filter((item) => item.quantity <= 10);
  const getCategories = () => [...new Set(INVENTORY.map((item) => item.category))];

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-cream-50 via-background to-cream-50 flex items-center justify-center py-8 px-4">
        <div className="w-full max-w-md animate-slide-up">
          {/* Security Notice */}
          <div className="bg-white rounded-2xl border border-cream-200 shadow-lg p-8 space-y-6">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-200 to-teal-200 rounded-full flex items-center justify-center">
                <Lock className="w-8 h-8 text-emerald-700" />
              </div>
            </div>

            <div className="space-y-2 text-center">
              <h1 className="font-display text-3xl text-foreground">MILO</h1>
              <p className="text-sm font-semibold text-emerald-600 uppercase tracking-wide">
                Warehouse Inventory System
              </p>
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mt-4">
                <p className="text-xs font-semibold text-red-700 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  FOR AUTHORIZED WORKERS ONLY
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Worker Passcode
                </label>
                <div className="relative">
                  <input
                    type={showPasscode ? "text" : "password"}
                    value={passcode}
                    onChange={(e) => {
                      setPasscode(e.target.value);
                      setAuthError("");
                    }}
                    onKeyPress={(e) => {
                      if (e.key === "Enter") {
                        handleAuthenticate();
                      }
                    }}
                    placeholder="Enter passcode"
                    className="w-full px-4 py-3 border border-cream-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-cream-50"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasscode(!showPasscode)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground/50 hover:text-foreground transition-colors"
                  >
                    {showPasscode ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {authError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <p className="text-sm text-red-700">{authError}</p>
                </div>
              )}

              <button
                onClick={handleAuthenticate}
                className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold py-3 rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5" />
                Access Inventory
              </button>
            </div>

            <div className="border-t border-cream-200 pt-6">
              <p className="text-xs text-foreground/50 text-center">
                This system is restricted to authorized company personnel. Unauthorized access is prohibited.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Authenticated View
  return (
    <div className="min-h-screen bg-gradient-to-b from-cream-50 via-background to-cream-50 py-8 md:py-12">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-200 to-teal-200 rounded-full flex items-center justify-center">
                <Package className="w-6 h-6 text-emerald-700" />
              </div>
              <div>
                <h1 className="font-display text-3xl md:text-4xl text-foreground">
                  MILO
                </h1>
                <p className="text-sm font-semibold text-emerald-600">
                  Warehouse Inventory
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="px-6 py-2 bg-red-100 hover:bg-red-200 text-red-700 font-semibold rounded-lg transition-colors"
          >
            Logout
          </button>
        </div>

        {/* Welcome Banner */}
        <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-6 mb-8">
          <div className="flex items-center gap-3 mb-2">
            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
            <h2 className="font-semibold text-emerald-900">
              Access Granted ✓
            </h2>
          </div>
          <p className="text-emerald-800">
            Welcome to the warehouse inventory system. Below is our current stock status across all categories.
          </p>
        </div>

        {/* Summary Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="card-luxury">
            <p className="text-sm text-foreground/60 mb-2">Total Items</p>
            <p className="font-display text-3xl text-foreground">
              {INVENTORY.reduce((sum, item) => sum + item.quantity, 0)}
            </p>
          </div>

          <div className="card-luxury">
            <p className="text-sm text-foreground/60 mb-2">Total SKUs</p>
            <p className="font-display text-3xl text-foreground">
              {INVENTORY.length}
            </p>
          </div>

          <div className="card-luxury">
            <p className="text-sm text-foreground/60 mb-2">Categories</p>
            <p className="font-display text-3xl text-foreground">
              {getCategories().length}
            </p>
          </div>

          <div className="card-luxury border-2 border-red-200 bg-red-50/50">
            <p className="text-sm text-red-700 font-semibold mb-2">
              ⚠️ Low Stock Items
            </p>
            <p className="font-display text-3xl text-red-700">
              {getLowStockItems().length}
            </p>
          </div>
        </div>

        {/* Low Stock Alert */}
        {getLowStockItems().length > 0 && (
          <div className="bg-yellow-50 border-l-4 border-yellow-500 rounded-lg p-6 mb-8">
            <h3 className="font-semibold text-yellow-900 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Items Running Low on Stock
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              {getLowStockItems().map((item) => (
                <div
                  key={item.sku}
                  className="bg-white rounded-lg p-4 border border-yellow-200"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-semibold text-foreground">
                        {item.name}
                      </p>
                      <p className="text-xs text-foreground/60 mt-1">
                        {item.category} • {item.sku}
                      </p>
                    </div>
                    <span className="text-xl font-bold text-red-600">
                      {item.quantity}
                    </span>
                  </div>
                  <p className="text-xs text-yellow-700 mt-3">
                    Contact warehouse manager for restocking
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Inventory by Category */}
        <div className="space-y-6">
          {getCategories().map((category) => {
            const categoryItems = INVENTORY.filter(
              (item) => item.category === category
            );
            return (
              <div key={category} className="space-y-3">
                <h3 className="font-display text-xl text-foreground">
                  {category}
                </h3>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b-2 border-cream-200">
                        <th className="text-left px-4 py-3 font-semibold text-foreground">
                          Item
                        </th>
                        <th className="text-left px-4 py-3 font-semibold text-foreground">
                          SKU
                        </th>
                        <th className="text-right px-4 py-3 font-semibold text-foreground">
                          In Stock
                        </th>
                        <th className="text-center px-4 py-3 font-semibold text-foreground">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {categoryItems.map((item) => (
                        <tr
                          key={item.sku}
                          className="border-b border-cream-200 hover:bg-cream-50 transition-colors"
                        >
                          <td className="px-4 py-4 font-medium text-foreground">
                            {item.name}
                          </td>
                          <td className="px-4 py-4 text-sm text-foreground/60">
                            {item.sku}
                          </td>
                          <td className="px-4 py-4 text-right">
                            <span
                              className={`inline-block px-3 py-1 rounded-full font-bold ${
                                item.quantity > 50
                                  ? "bg-green-100 text-green-700"
                                  : item.quantity > 10
                                    ? "bg-blue-100 text-blue-700"
                                    : "bg-red-100 text-red-700"
                              }`}
                            >
                              {item.quantity}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-center">
                            {item.quantity > 50 ? (
                              <span className="text-xs font-semibold text-green-700 bg-green-50 px-3 py-1 rounded-full">
                                ✓ Abundant
                              </span>
                            ) : item.quantity > 10 ? (
                              <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-3 py-1 rounded-full">
                                ℹ️ Adequate
                              </span>
                            ) : (
                              <span className="text-xs font-semibold text-red-700 bg-red-50 px-3 py-1 rounded-full">
                                ⚠️ Low Stock
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Info */}
        <div className="mt-12 bg-white rounded-2xl border border-cream-200 shadow-lg p-8 space-y-4">
          <h3 className="font-semibold text-foreground text-lg">
            Warehouse Management
          </h3>
          <ul className="space-y-3 text-foreground/70">
            <li className="flex items-start gap-3">
              <span className="text-emerald-600 font-bold flex-shrink-0">•</span>
              <span>
                For restocking requests, contact the warehouse manager
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-emerald-600 font-bold flex-shrink-0">•</span>
              <span>
                Items marked as "Low Stock" should be prioritized for ordering
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-emerald-600 font-bold flex-shrink-0">•</span>
              <span>
                This inventory system is updated daily and reflects real-time
                stock
              </span>
            </li>
          </ul>
        </div>

        {/* Logout Reminder */}
        <div className="text-center mt-8">
          <p className="text-sm text-foreground/50">
            Remember to log out when finished for security purposes
          </p>
        </div>
      </div>
    </div>
  );
}
