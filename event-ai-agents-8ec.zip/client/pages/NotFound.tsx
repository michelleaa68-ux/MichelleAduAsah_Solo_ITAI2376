import { Link } from "react-router-dom";
import { Home, ArrowRight } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-cream-50 via-background to-cream-50 flex items-center justify-center py-8 px-4">
      <div className="max-w-md text-center space-y-8 animate-fade-in">
        <div className="space-y-4">
          <div className="text-6xl md:text-8xl font-display text-gradient">
            404
          </div>
          <h1 className="font-display text-3xl md:text-4xl text-foreground">
            Page Not Found
          </h1>
          <p className="text-lg text-foreground/60 leading-relaxed">
            The page you're looking for doesn't exist or has been moved. Let's get you back to creating something beautiful!
          </p>
        </div>

        <div className="space-y-3">
          <Link
            to="/"
            className="inline-flex items-center justify-center gap-2 btn-primary text-lg w-full"
          >
            <Home className="w-5 h-5" />
            Back to Home
          </Link>

          <Link
            to="/mira"
            className="inline-flex items-center justify-center gap-2 btn-outline text-lg w-full"
          >
            Chat with MIRA <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="pt-8 space-y-3 border-t border-cream-200">
          <p className="text-sm font-semibold text-foreground/50 uppercase tracking-wide">
            Quick Links
          </p>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Home", href: "/" },
              { label: "MIRA", href: "/mira" },
              { label: "MIZEL", href: "/mizel" },
            ].map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className="px-3 py-2 rounded-lg bg-cream-100 hover:bg-cream-200 text-foreground text-sm font-semibold transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
