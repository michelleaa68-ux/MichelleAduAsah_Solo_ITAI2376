import { Link } from "react-router-dom";
import { MessageCircle, Palette, Package, ArrowRight, Sparkles } from "lucide-react";

export default function Index() {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[600px] md:min-h-[700px] flex items-center justify-center px-4 py-20 md:py-32">
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute top-20 right-20 w-72 h-72 bg-primary/10 rounded-full blur-3xl opacity-50"></div>
          <div className="absolute bottom-20 left-20 w-72 h-72 bg-secondary/10 rounded-full blur-3xl opacity-50"></div>
        </div>

        <div className="max-w-4xl mx-auto text-center space-y-8 animate-fade-in">
          <div className="inline-flex items-center gap-2 bg-cream-100 border border-primary/20 rounded-full px-4 py-2">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-primary">AI-Powered Event Planning</span>
          </div>

          <h1 className="font-display text-5xl md:text-7xl leading-tight text-gradient">
            Transform Your Vision Into Reality
          </h1>

          <p className="text-lg md:text-xl text-foreground/70 max-w-2xl mx-auto leading-relaxed">
            Meet our three specialized AI agents designed to make your event planning seamless, creative, and luxurious. From initial questions to final inventory management, we've got you covered.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Link
              to="/mira"
              className="inline-flex items-center justify-center gap-2 btn-primary text-lg"
            >
              Get Started <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="#agents"
              className="inline-flex items-center justify-center gap-2 btn-outline text-lg"
            >
              Learn More
            </a>
          </div>
        </div>
      </section>

      {/* Agents Section */}
      <section id="agents" className="py-20 md:py-32 px-4 bg-white/30 backdrop-blur-sm border-y border-cream-200">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="font-display text-4xl md:text-5xl text-foreground">
              Meet Your AI Agents
            </h2>
            <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
              Three specialized agents working together to deliver exceptional event experiences
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* MIRA Card */}
            <div className="card-luxury group">
              <div className="w-24 h-24 rounded-full overflow-hidden mb-6 group-hover:scale-110 transition-transform border-4 border-primary/20">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets%2F8b759b000619420db3b245254c7ffeda%2Faee0a0091e9e486280f2ba0c6f0299bf?format=webp&width=800&height=1200"
                  alt="MIRA - Client Assistant"
                  className="w-full h-full object-cover overflow-hidden"
                />
              </div>

              <h3 className="text-2xl font-display text-foreground mb-3">MIRA</h3>
              <p className="text-sm font-semibold text-primary uppercase tracking-wide mb-4">
                Client Assistant
              </p>

              <p className="text-foreground/70 mb-6 leading-relaxed">
                Your dedicated chatbot answering all client questions: pricing, availability, appointments, booking details, and more.
              </p>

              <ul className="space-y-2 mb-8 text-sm text-foreground/60">
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>24/7 FAQ Support</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>Pricing & Packages</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>Booking Assistance</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>Venue & Service Info</span>
                </li>
              </ul>

              <Link
                to="/mira"
                className="inline-flex items-center gap-2 font-semibold text-primary hover:gap-3 transition-all"
              >
                Chat with MIRA <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* MIZEL Card */}
            <div className="card-luxury group">
              <div className="w-24 h-24 rounded-full overflow-hidden mb-6 group-hover:scale-110 transition-transform border-4 border-secondary/20">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets%2F8b759b000619420db3b245254c7ffeda%2F7520b2250291437fa7204aa70e60b5c3?format=webp&width=800&height=1200"
                  alt="MIZEL - Creative Director"
                  className="w-full h-full object-cover overflow-hidden"
                />
              </div>

              <h3 className="text-2xl font-display text-foreground mb-3">MIZEL</h3>
              <p className="text-sm font-semibold text-secondary uppercase tracking-wide mb-4">
                Creative Director
              </p>

              <p className="text-foreground/70 mb-6 leading-relaxed">
                Your creative genius turning visions into stunning design realities with custom mood boards and color palettes.
              </p>

              <ul className="space-y-2 mb-8 text-sm text-foreground/60">
                <li className="flex items-start gap-2">
                  <span className="text-secondary font-bold">•</span>
                  <span>Vision to Design</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-secondary font-bold">•</span>
                  <span>Custom Mood Boards</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-secondary font-bold">•</span>
                  <span>Color Palettes</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-secondary font-bold">•</span>
                  <span>Design Recommendations</span>
                </li>
              </ul>

              <Link
                to="/mizel"
                className="inline-flex items-center gap-2 font-semibold text-secondary hover:gap-3 transition-all"
              >
                Explore Design <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* MILO Card */}
            <div className="card-luxury group">
              <div className="w-24 h-24 rounded-full overflow-hidden mb-6 group-hover:scale-110 transition-transform border-4 border-emerald-200/50">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets%2F8b759b000619420db3b245254c7ffeda%2F908769a8e0cd442e85d5125d2703a1dd?format=webp&width=800&height=1200"
                  alt="MILO - Inventory Manager"
                  className="w-full h-full object-cover overflow-hidden"
                />
              </div>

              <h3 className="text-2xl font-display text-foreground mb-3">MILO</h3>
              <p className="text-sm font-semibold text-emerald-600 uppercase tracking-wide mb-4">
                Inventory Manager
              </p>

              <p className="text-foreground/70 mb-6 leading-relaxed">
                Real-time warehouse inventory access for team members. Password-protected for authorized personnel only.
              </p>

              <ul className="space-y-2 mb-8 text-sm text-foreground/60">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>Real-Time Stock</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>Item Catalog</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>Low Stock Alerts</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>Secure Access</span>
                </li>
              </ul>

              <Link
                to="/milo"
                className="inline-flex items-center gap-2 font-semibold text-emerald-600 hover:gap-3 transition-all"
              >
                Check Inventory <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 md:py-32 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="font-display text-4xl md:text-5xl text-foreground">
              Why Choose Us
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: "Luxury Design",
                description: "Stunning, sophisticated designs that elevate every celebration",
              },
              {
                title: "Expert Guidance",
                description: "AI-powered recommendations tailored to your vision and budget",
              },
              {
                title: "Real-Time Inventory",
                description: "Know exactly what's available for your special day",
              },
              {
                title: "Seamless Planning",
                description: "From concept to execution, every detail perfected",
              },
              {
                title: "Creative Innovation",
                description: "Transform your ideas into unforgettable experiences",
              },
              {
                title: "Dedicated Support",
                description: "24/7 assistance through our intelligent AI team",
              },
            ].map((feature, i) => (
              <div key={i} className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-gradient-to-br from-primary to-secondary rounded-lg shadow-lg">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-foreground/60 text-sm">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 px-4 bg-gradient-to-r from-primary/10 via-secondary/10 to-primary/10 border-y border-cream-200">
        <div className="max-w-2xl mx-auto text-center space-y-8">
          <h2 className="font-display text-4xl md:text-5xl text-foreground">
            Ready to Transform Your Event?
          </h2>

          <p className="text-lg text-foreground/70">
            Start with MIRA to answer all your questions, then explore MIZEL's creative magic for your dream design.
          </p>

          <Link to="/mira" className="inline-flex items-center gap-2 btn-primary text-lg">
            Begin Your Journey <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
