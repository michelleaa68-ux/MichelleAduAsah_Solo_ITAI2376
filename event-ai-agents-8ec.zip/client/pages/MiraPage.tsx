import { useState, useRef, useEffect } from "react";
import { Send, MessageCircle, Sparkles } from "lucide-react";

interface Message {
  id: string;
  type: "user" | "mira";
  content: string;
  timestamp: Date;
}

const MIRA_RESPONSES: Record<string, string> = {
  price: `Our packages are tailored to your vision:
  
  💎 Elegance: $2,500–$5,000
  Intimate gatherings with elegant touches
  
  👑 Luxe: $5,000–$12,000
  Full event transformation with premium elements
  
  ✨ Couture: Custom Quoted
  Bespoke design based on your vision and guest count
  
  Let me know the size and style of your event for a detailed quote!`,

  appointment: `We'd love to meet with you! 
  
  📅 Free 30-Minute Discovery Call
  Schedule at least 8 weeks before your event for best availability
  
  📧 Email: hello@events.com
  📞 Phone: (713) 555-0192
  
  Popular dates book quickly, so reach out soon!`,

  availability: `📅 We're Available:
  
  🌍 Service Area: Houston Metro, Sugar Land, Katy, Pearland, The Woodlands
  Destination events available (travel rates apply)
  
  ⏰ Consultation Hours:
  Monday - Saturday, 9AM - 6PM CST
  
  After-hours email inquiries answered within 24 hours.
  
  When are you planning your special event?`,

  booking: `To Secure Your Date:
  
  ✅ Step 1: Sign contract
  ✅ Step 2: 30% deposit
  ✅ Step 3: Final balance due 2 weeks before event
  
  We'll guide you through every step. Contact us today!
  
  📧 hello@events.com
  📞 (713) 555-0192`,

  delivery: `🚚 Our Full-Service Setup:
  
  ✓ Complete delivery to your venue
  ✓ Professional setup and installation
  ✓ Full breakdown after your event
  
  💰 Transport & Setup: Starting at $350
  Varies based on venue distance and event size
  
  Everything is included in your final quote—no surprise fees!`,

  refund: `💜 Our Cancellation Policy:
  
  📅 60+ days before: Full refund minus $200 processing fee
  📅 30-60 days before: Store credit at our discretion
  📅 Within 30 days: Non-refundable
  
  Please contact us as early as possible if plans change.
  
  📧 hello@events.com
  📞 (713) 555-0192`,

  table: `🍽️ Table Setting Enhancements:
  
  🥇 Charger Plates: Starting at $2 each
  ✨ Linen Upgrades: Starting at $15 per table
  🌸 Centerpiece Upgrades: Custom quoted based on florals
  
  Mix and match to create your perfect tablescapes!
  What style are you envisioning?`,

  chandelier: `💎 Chandelier Details:
  
  📏 Diameter Range: 24" to 48"
  📍 Standard Hang Drop: 6-10 feet from ceiling
  ⚡ Height adjusted during site visit for your venue's clearance
  
  We customize based on your venue and vision.
  Tell us about your space!`,

  flowers: `🌹 We offer exquisite floral designs:
  
  Popular Combinations:
  ✨ Ivory, White Florals with Gold Accents
  💕 Blush Pink with Garden Roses
  👑 Royal Whites with Gold Details
  🌺 Bold Reds & Burgundy with Lush Greenery
  
  Custom floral arrangements quoted individually.
  What's your color vision?`,
};

const getSuggestions = (question: string): string => {
  const lower = question.toLowerCase();

  // Check for multiple keywords
  if (
    lower.includes("price") ||
    lower.includes("cost") ||
    lower.includes("how much") ||
    lower.includes("package")
  ) {
    return MIRA_RESPONSES.price;
  } else if (
    lower.includes("appointment") ||
    lower.includes("meet") ||
    lower.includes("consultation") ||
    lower.includes("schedule") ||
    lower.includes("contact")
  ) {
    return MIRA_RESPONSES.appointment;
  } else if (
    lower.includes("availability") ||
    lower.includes("available") ||
    lower.includes("where") ||
    lower.includes("location") ||
    lower.includes("area")
  ) {
    return MIRA_RESPONSES.availability;
  } else if (
    lower.includes("book") ||
    lower.includes("reserve") ||
    lower.includes("deposit")
  ) {
    return MIRA_RESPONSES.booking;
  } else if (
    lower.includes("delivery") ||
    lower.includes("transport") ||
    lower.includes("setup") ||
    lower.includes("install")
  ) {
    return MIRA_RESPONSES.delivery;
  } else if (lower.includes("cancel") || lower.includes("refund")) {
    return MIRA_RESPONSES.refund;
  } else if (
    lower.includes("table") ||
    lower.includes("charger") ||
    lower.includes("linen") ||
    lower.includes("centerpiece")
  ) {
    return MIRA_RESPONSES.table;
  } else if (lower.includes("chandelier") || lower.includes("height")) {
    return MIRA_RESPONSES.chandelier;
  } else if (lower.includes("flower") || lower.includes("floral")) {
    return MIRA_RESPONSES.flowers;
  }

  return `Thank you for your question! I'm here to help with pricing, appointments, availability, booking details, delivery, and design questions.

Feel free to ask me about:
• 💰 Pricing & Packages
• 📅 Booking & Appointments
• 📍 Availability & Locations
• 🚚 Delivery & Setup
• 🌸 Design Details

What can I help you with today?`;
};

export default function MiraPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "mira",
      content: `Hello! 👋 I'm MIRA, your client assistant for all things event planning. 

I'm here to help with:
• 💰 Pricing & Packages
• 📅 Appointments & Availability
• 🎨 Design Questions
• 🚚 Delivery & Setup Details
• 📋 Booking & Policies

What can I help you with today?`,
      timestamp: new Date(),
    },
  ]);

  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    // Simulate AI response delay
    await new Promise((resolve) => setTimeout(resolve, 800));

    const response = getSuggestions(input);
    const miraMessage: Message = {
      id: (Date.now() + 1).toString(),
      type: "mira",
      content: response,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, miraMessage]);
    setIsLoading(false);
  };

  const quickQuestions = [
    "What are your pricing options?",
    "How do I book an appointment?",
    "What areas do you service?",
    "What's your cancellation policy?",
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream-50 via-background to-cream-50 py-8 md:py-12">
      <div className="max-w-4xl mx-auto h-[calc(100vh-200px)] md:h-[600px] flex flex-col">
        {/* Header */}
        <div className="mb-6 text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-2">
            <MessageCircle className="w-5 h-5 text-primary" />
            <span className="font-semibold text-primary">MIRA Assistant</span>
          </div>

          <h1 className="font-display text-4xl text-foreground">
            Chat with MIRA
          </h1>
          <p className="text-foreground/60">
            Ask any questions about our services, pricing, and event planning
          </p>
        </div>

        {/* Chat Container */}
        <div className="flex-1 bg-white rounded-2xl border border-cream-200 shadow-lg overflow-hidden flex flex-col">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${
                  msg.type === "user" ? "justify-end" : "justify-start"
                } animate-slide-up`}
              >
                <div
                  className={`max-w-xs md:max-w-md lg:max-w-lg xl:max-w-xl px-4 py-3 rounded-2xl whitespace-pre-wrap leading-relaxed ${
                    msg.type === "user"
                      ? "bg-gradient-to-r from-primary to-rose-600 text-white rounded-br-none"
                      : "bg-cream-100 text-foreground border border-cream-200 rounded-bl-none"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-cream-100 border border-cream-200 rounded-2xl rounded-bl-none px-4 py-3">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-200"></div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Questions */}
          {messages.length <= 1 && (
            <div className="border-t border-cream-200 p-4">
              <p className="text-xs font-semibold text-foreground/50 uppercase mb-3">
                Quick Questions
              </p>
              <div className="grid grid-cols-1 gap-2">
                {quickQuestions.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setInput(q);
                    }}
                    className="text-left text-sm px-3 py-2 rounded-lg bg-cream-100 hover:bg-cream-200 text-foreground transition-colors"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="border-t border-cream-200 p-4 bg-white">
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Ask MIRA anything..."
                className="flex-1 px-4 py-3 border border-cream-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary bg-cream-50"
                disabled={isLoading}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="bg-primary hover:bg-rose-700 disabled:bg-foreground/20 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center gap-2"
              >
                <Send className="w-5 h-5" />
                <span className="hidden sm:inline">Send</span>
              </button>
            </div>
            <p className="text-xs text-foreground/50 mt-2">
              💡 Tip: Ask about pricing, bookings, availability, or design details
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
