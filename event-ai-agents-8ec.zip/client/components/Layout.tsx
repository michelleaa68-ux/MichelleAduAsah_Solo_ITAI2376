import { Outlet, Link, useLocation } from "react-router-dom";
import { Sparkles } from "lucide-react";

export default function Layout() {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream-50 via-background to-cream-50 flex flex-col">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 backdrop-blur-lg bg-white/80 border-b border-cream-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-rose-600 rounded-lg flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="font-display text-2xl bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent hidden sm:inline">
                Transforming Events
              </span>
            </Link>

            <div className="flex items-center gap-2 sm:gap-4">
              <Link
                to="/"
                className={`px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  isActive("/")
                    ? "bg-primary text-white shadow-lg"
                    : "text-foreground hover:bg-cream-100"
                }`}
              >
                Home
              </Link>
              <Link
                to="/mira"
                className={`px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  isActive("/mira")
                    ? "bg-primary text-white shadow-lg"
                    : "text-foreground hover:bg-cream-100"
                }`}
              >
                <span className="hidden sm:inline">MIRA</span>
                <span className="sm:hidden">Chat</span>
              </Link>
              <Link
                to="/mizel"
                className={`px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  isActive("/mizel")
                    ? "bg-primary text-white shadow-lg"
                    : "text-foreground hover:bg-cream-100"
                }`}
              >
                <span className="hidden sm:inline">MIZEL</span>
                <span className="sm:hidden">Design</span>
              </Link>
              <Link
                to="/milo"
                className={`px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  isActive("/milo")
                    ? "bg-primary text-white shadow-lg"
                    : "text-foreground hover:bg-cream-100"
                }`}
              >
                <span className="hidden sm:inline">MILO</span>
                <span className="sm:hidden">Inv.</span>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t border-cream-200 bg-white/50 backdrop-blur-sm mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            <div>
              <h3 className="font-display text-xl text-primary mb-4">Transforming Spaces</h3>
              <p className="text-foreground/70 text-sm">
                Creating unforgettable experiences through luxury event design and exceptional service.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Our Agents</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><Link to="/mira" className="hover:text-primary transition-colors">MIRA - Client Support</Link></li>
                <li><Link to="/mizel" className="hover:text-primary transition-colors">MIZEL - Creative Design</Link></li>
                <li><Link to="/milo" className="hover:text-primary transition-colors">MILO - Inventory</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>📧 hello@events.com</li>
                <li>📞 (713) 555-0192</li>
                <li>🌍 Houston, TX</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-cream-200 mt-8 pt-8 text-center text-sm text-foreground/60">
            <p>© 2026 Transforming Spaces. Bringing visions to life.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
