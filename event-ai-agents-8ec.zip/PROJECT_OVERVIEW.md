# Transforming Spaces - AI-Powered Event Planning System

## Overview

A beautiful, luxury event planning application featuring three specialized AI agents working together to deliver exceptional experiences for clients and streamline operations for internal teams.

## The Three AI Agents

### 🎤 **MIRA** - Client Assistant
**Purpose**: 24/7 client support and FAQ chatbot

**Capabilities**:
- Answer pricing and package questions
- Schedule appointments and consultations
- Provide service area and availability information
- Handle booking, deposit, and refund policy questions
- Discuss floral arrangements, chandeliers, and table settings
- Address delivery, setup, and transport inquiries

**Access**: Public - available to all clients

**Key Features**:
- Real-time conversational responses
- Keyword-based intelligent routing
- Quick suggestion buttons for common questions
- Professional yet inviting tone

### 🎨 **MIZEL** - Creative Director
**Purpose**: Transform client visions into stunning design concepts

**Capabilities**:
- Generate custom color palettes based on event vision
- Create detailed mood boards with specific recommendations
- Suggest floral arrangements, linens, and decorative elements
- Provide lighting and ambiance guidance
- Create design narratives for different event styles

**Access**: Public - available to all clients

**Design Specialties**:
- Garden Romance (whites, sage green, soft gold)
- Blush Elegance (blush pink, champagne gold, dusty rose)
- Royal Grandeur (royal blue, gold, crisp white)
- Burgundy Luxury (deep burgundy, forest green, warm gold)
- Modern Minimalist (crisp white, slate grey, brushed silver)
- Timeless Warmth (ivory, soft gold, warm blush)

### 📦 **MILO** - Inventory Manager
**Purpose**: Real-time warehouse inventory tracking

**Access**: Workers only (password protected)
**Passcode**: `milo2376`

**Capabilities**:
- View complete inventory across all categories
- Track item quantities and stock levels
- Identify low-stock items (≤10 units)
- Categorize items by type (Furniture, Tableware, Linens, Lighting, Decor)
- Generate restocking alerts

**Current Inventory**:
- 150 Chairs
- 20 Tables
- 200 Charger Plates
- 40 Linen Tablecloths
- 300 Linen Napkins
- 250 Silverware Sets
- 3 Floral Arches ⚠️ (Low Stock)
- 12 Candelabras
- 24 Uplighting Units
- 8 Flower Wall Panels ⚠️ (Low Stock)

## Design System

### Color Palette
- **Primary**: Rose/Pink (#DB2777) - Main brand color
- **Secondary**: Gold (#FFB300) - Luxury accent
- **Cream**: Soft background (#FFFCF0) - Inviting and warm
- **Foreground**: Deep brown (#453420) - Text and details

### Typography
- **Display**: Playfair Display (elegant headings)
- **Body**: Inter (clean, readable body text)

### Visual Language
- Luxury and sophistication
- Light and inviting aesthetic
- Rounded corners and soft shadows
- Gradient accents
- Smooth animations and transitions

## Tech Stack

- **Frontend**: React 18 + React Router 6
- **Styling**: Tailwind CSS 3 + Custom CSS
- **UI Components**: Radix UI + Custom components
- **Icons**: Lucide React
- **State Management**: React hooks
- **Animations**: Tailwind CSS animations + custom keyframes

## Features

### Homepage
- Hero section with value proposition
- Agent showcase cards with descriptions
- Feature highlights section
- Call-to-action sections
- Sticky navigation

### MIRA Chat Interface
- Message-based conversation system
- Keyword-based intelligent responses
- Quick suggestion buttons
- Typing indicators
- Scrollable message history
- Mobile-optimized layout

### MIZEL Design Generator
- Vision description input
- Real-time mood board generation
- Interactive color palette display
- Design recommendations
- Floral suggestions
- Example vision templates
- Design consultation CTA

### MILO Inventory System
- Passcode-protected access (workers only)
- Real-time inventory dashboard
- Low-stock alerts and warnings
- Category-based organization
- Stock level indicators
- Restocking instructions

### Layout Components
- Responsive sticky navigation
- Comprehensive footer with links
- Consistent branding across all pages
- Mobile-first responsive design

## File Structure

```
client/
├── pages/
│   ├── Index.tsx          # Homepage
│   ├── MiraPage.tsx       # MIRA chatbot interface
│   ├── MizelPage.tsx      # MIZEL mood board generator
│   ├── MiloPage.tsx       # MILO inventory system
│   └── NotFound.tsx       # 404 error page
├── components/
│   ├── Layout.tsx         # Shared layout with nav & footer
│   └── ui/                # Pre-built UI components
├── App.tsx                # Router setup
├── global.css             # Theme variables & global styles
└── lib/
    └── utils.ts           # Utility functions

tailwind.config.ts         # Tailwind configuration
```

## Key Features Implemented

✅ Three-agent system with distinct roles
✅ Beautiful, luxury-focused design
✅ Responsive across all devices
✅ Real-time inventory tracking
✅ Password-protected worker access
✅ Intelligent chatbot with keyword routing
✅ Creative mood board generator
✅ Smooth animations and transitions
✅ Mobile-optimized navigation
✅ Professional footer with contact info
✅ Accessibility considerations
✅ Dark mode ready (theme structure in place)

## Customization

### Adding New Colors
Edit `tailwind.config.ts` and `client/global.css` to update:
- CSS color variables (HSL format)
- Tailwind theme extensions

### Extending MIRA's Responses
Edit `client/pages/MiraPage.tsx`:
- Add new keywords to `MIRA_RESPONSES` object
- Update `getSuggestions()` function with new conditions

### Adding MIZEL Palettes
Edit `client/pages/MizelPage.tsx`:
- Add new palette objects to `DESIGN_PALETTES`
- Update palette detection logic in `generateMoodBoard()`

### Updating MILO Inventory
Edit `client/pages/MiloPage.tsx`:
- Modify `INVENTORY` array with current stock items
- Update `WORKER_PASSCODE` for security

## Future Enhancements

- Database integration for persistent inventory
- Real AI/LLM backend integration (replacing keyword routing)
- Image uploads for MIZEL mood boards
- Client account management and booking history
- Event timeline and checklist features
- Virtual venue visualization (3D)
- Integration with payment processing
- Email notifications and confirmations
- Analytics dashboard for metrics tracking
- Multi-user support and roles

## Contact & Support

- Email: hello@events.com
- Phone: (713) 555-0192
- Location: Houston, TX
- Service Areas: Houston Metro, Sugar Land, Katy, Pearland, The Woodlands

---

**Built with luxury, creativity, and care.**
*Transforming Spaces into Experiences.*
